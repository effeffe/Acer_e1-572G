How to update the BIOS: 
Click "V5WE2217.exe" under Winodows mode

Release Note:
Improve ODD response speed